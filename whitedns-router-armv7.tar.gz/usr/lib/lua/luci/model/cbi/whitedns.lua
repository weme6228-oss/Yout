-- WhiteDNS LuCI page (Map/CBI) — OpenWrt 25.12
local m, s, o
local run = luci.sys.exec("/usr/bin/whitedns-ctl status 2>&1")

m = Map("whitedns", translate("WhiteDNS"),
	translate("DNS tunnel client — CottenDNS / Soar, SOCKS5 outlet for Passwall2") .. "<br/><b>" .. run:gsub("\n", "<br/>") .. "</b>")

s = m:section(NamedSection, "config", "whitedns", translate("Settings"))
s.addremove = false
s.anonymous = true

o = s:option(ListValue, "engine", translate("Engine"))
o:value("cottendns", "CottenDNS (domain + key)")
o:value("soar", "Soar (WhiteDNS panel)")
o.default = "cottendns"

o = s:option(Flag, "enabled", translate("Start at boot"))
o.enabled = "1"
o.disabled = "0"
o.default = "0"

-- CottenDNS fields
o = s:option(Value, "domains", translate("Tunnel domain(s)"), translate("CottenDNS: e.g. v.example.com"))
o:depends("engine", "cottendns")

o = s:option(Value, "key", translate("Encryption key"), translate("CottenDNS: must match server"))
o.password = true
o:depends("engine", "cottendns")

o = s:option(ListValue, "encryption", translate("Encryption method"))
o:value("0", "None")
o:value("1", "XOR")
o:value("2", "ChaCha20")
o:value("3", "AES-128-GCM")
o:value("4", "AES-192-GCM")
o:value("5", "AES-256-GCM")
o.default = "3"
o:depends("engine", "cottendns")

-- Soar fields
o = s:option(Value, "zone", translate("Tunnel zone"), translate("Soar: lowercase tunnel domain"))
o:depends("engine", "soar")

o = s:option(Value, "server_public_key", translate("Server public key"), translate("Soar: base64 server key"))
o.password = true
o:depends("engine", "soar")

o = s:option(Value, "username", translate("Panel username"))
o:depends("engine", "soar")

o = s:option(Value, "password", translate("Panel password"))
o.password = true
o:depends("engine", "soar")

-- Shared
o = s:option(ListValue, "listen_ip", translate("Listen IP"))
o:value("127.0.0.1", "127.0.0.1 (local only)")
o:value("0.0.0.0", "0.0.0.0 (LAN devices)")
o.default = "127.0.0.1"

o = s:option(Value, "listen_port", translate("SOCKS5 port"))
o.datatype = "port"
o.default = "18000"

o = s:option(Value, "memlimit_mb", translate("Memory limit (MB)"), translate("GOMEMLIMIT guard for the engine process"))
o.datatype = "uinteger"
o.default = "48"

o = s:option(TextValue, "_resolvers", translate("Resolver list"), translate("One resolver per line (IP or host:port). Saved to /etc/whitedns/resolvers.txt"))
o.rows = 6
o.cfgvalue = function(self, section)
	local f = io.open("/etc/whitedns/resolvers.txt", "r")
	local c = f and f:read("*a") or ""
	if f then f:close() end
	return c
end
o.write = function(self, section, value)
	if value then
		local f = io.open("/etc/whitedns/resolvers.txt", "w")
		if f then f:write(value) f:close() end
	end
end

o = s:option(TextValue, "_import", translate("Import profile URL"), translate("Paste cottendns://... or soar://... link, then press Import. Result appears in Status line above."))
o.rows = 2
o.cfgvalue = function(self, section) return "" end
o.write = function(self, section, value) end  -- not persisted; button does the work

o = s:option(Button, "_do_import", translate("Import"))
o.inputstyle = "apply"
o.write = function(self, section)
	local http = require "luci.http"
	local v = http.formvalue("cbid.whitedns.config._import") or ""
	if #v > 10 then
		-- quote-safe pass to shell
		local q = v:gsub("'", "")
		local out = luci.sys.exec("/usr/bin/whitedns-import '" .. q .. "' 2>&1")
		self.description = (out or ""):gsub("
", "<br/>")
		-- refresh UCI-backed fields on the page
		self.map.uci:load("whitedns")
	end
end

o = s:option(Button, "_apply_restart", translate("Apply & Restart"))
o.inputtitle = translate("Restart")
o.inputstyle = "apply"
function o.write(self, section)
	luci.sys.exec("/usr/bin/whitedns-ctl restart >/dev/null 2>&1 &")
end

o = s:option(Button, "_stop", translate("Stop"))
o.inputstyle = "remove"
function o.write(self, section)
	luci.sys.exec("/usr/bin/whitedns-ctl stop >/dev/null 2>&1")
end

return m
