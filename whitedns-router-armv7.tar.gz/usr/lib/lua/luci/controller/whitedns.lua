#!/bin/sh
# LuCI controller for WhiteDNS (OpenWrt 25.12)
module("luci.controller.whitedns", package.seeall)

function index()
	if not nixio.fs.access("/etc/config/whitedns") then
		return
	end
	entry({"admin", "services", "whitedns"}, cbi("whitedns"), _("WhiteDNS"), 60).dependent = true
	entry({"admin", "services", "whitedns_status"}, call("action_status")).leaf = true
	entry({"admin", "services", "whitedns_log"}, call("action_log")).leaf = true
end

function action_status()
	local http = require "luci.http"
	local ctl = "/usr/bin/whitedns-ctl"
	local f = io.popen(ctl .. " status 2>&1")
	local out = f:read("*a") or ""
	f:close()
	http.prepare_content("application/json")
	http.write_json({status = out})
end

function action_log()
	local http = require "luci.http"
	local f = io.open("/var/log/whitedns.log", "r")
	local out = f and f:read("*a") or ""
	if f then f:close() end
	-- last 8000 chars only (keep memory low on 482MB router)
	if #out > 8000 then out = out:sub(-8000) end
	http.prepare_content("text/plain; charset=utf-8")
	http.write(out)
end
